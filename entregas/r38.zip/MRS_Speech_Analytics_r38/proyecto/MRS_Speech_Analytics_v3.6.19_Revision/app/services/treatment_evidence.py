"""Quejas y expresiones despectivas: evidencia textual sin inventar tono."""
import re

from app.services.conversation_evidence import normalize, sentence_evidence


def mistreatment_reports(text, segments, phrases):
    evidence = []
    variants = re.compile(
        r'\bme contest(?:o|aron|aban|aba) (?:muy )?mal\b|'
        r'\b(?:una? |su companer[oa] |tu companer[oa] )?me amenazo\b')
    for unit in sentence_evidence(text, segments):
        if unit['speaker_role'] == 'GESTOR':
            continue
        value = normalize(unit['text'])
        matches = [m for phrase in phrases for m in re.finditer(re.escape(normalize(phrase)), value)]
        matches.extend(variants.finditer(value))
        for match in matches:
            before = value[max(0, match.start()-50):match.start()]
            if re.search(r'\b(?:no|nunca|jamas|nadie)\s*$', before):
                continue
            if value.rfind('¿', 0, match.start()) > max(value.rfind(c, 0, match.start()) for c in '.!?'):
                continue
            evidence.append(dict(unit, phrase=match.group()))
    return evidence


def dismissive_message_evidence(text, segments=()):
    evidence = []
    pattern = re.compile(r'\b(?:nada mas|solo) (?:seria|es|va a ser) (?:como )?(?:un )?chisme\b')
    for unit in sentence_evidence(text, segments):
        if unit['speaker_role'] in {'TITULAR', 'TERCERO', 'INTERLOCUTOR'}:
            continue
        value = normalize(unit['text'])
        for match in pattern.finditer(value):
            prefix = value[max(0, match.start()-65):match.start()]
            if re.search(r'\b(?:no|nunca|dice que|dijo que|me dijeron que|usted dijo que)\s*$', prefix):
                continue
            evidence.append(dict(unit, phrase=match.group()))
    return evidence


def offensive_asr_variants(text):
    """Variantes acotadas; no tomar «tarjetaunching» como insulto confirmado."""
    return [m.group() for m in re.finditer(
        r'\bching(?:uy|ui|ue)\s*(?:y\s*)?ching(?:uy|ui|ue)\b|'
        r'\b(?:una|la|su)chingada\b', normalize(text))]
